require('dotenv').config();
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const rateLimit = require('express-rate-limit');
const { setIO } = require('./services/whatsappService');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST'],
  },
});

// Injetar socket.io no serviço de WhatsApp
setIO(io);

// Middlewares
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
app.use('/api/', limiter);

// Rotas
app.use('/api/auth', require('./routes/auth'));
app.use('/api/contacts', require('./routes/contacts'));
app.use('/api/pipeline', require('./routes/pipeline'));
app.use('/api/whatsapp', require('./routes/whatsapp'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/tenants', require('./routes/tenants'));

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'ok', version: '1.0.0', timestamp: new Date() }));

// Socket.IO - autenticação e salas por tenant
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Token necessário'));

  const jwt = require('jsonwebtoken');
  const db = require('./database');
  const JWT_SECRET = process.env.JWT_SECRET || 'soft-ia-house-secret-key';

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(decoded.userId);
    if (!user) return next(new Error('Usuário não encontrado'));
    socket.user = user;
    socket.tenantId = user.tenant_id;
    next();
  } catch {
    next(new Error('Token inválido'));
  }
});

io.on('connection', (socket) => {
  socket.join(`tenant_${socket.tenantId}`);
  console.log(`✅ Socket: ${socket.user?.name} conectado`);
  socket.on('disconnect', () => console.log(`❌ Socket: ${socket.user?.name} desconectado`));
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════╗
║   🚀 CRM Soft IA House - Backend      ║
║   📡 API: http://localhost:${PORT}/api   ║
║   🌍 Env: ${process.env.NODE_ENV || 'development'}                 ║
╚═══════════════════════════════════════╝
  `);
});

module.exports = { app, server };
